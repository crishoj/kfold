
require 'kfold/data_file'

module Kfold
  VERSION = 0.1
  
end
