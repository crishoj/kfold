$LOAD_PATH.unshift File.dirname(__FILE__) + '/..'
 
require 'spec'